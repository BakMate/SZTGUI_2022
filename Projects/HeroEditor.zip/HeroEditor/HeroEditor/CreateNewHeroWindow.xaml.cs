﻿using HeroEditor.Enumerations;
using HeroEditor.Logic;
using HeroEditor.Models;
using HeroEditor.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HeroEditor
{
    /// <summary>
    /// Interaction logic for CreateNewHeroWindow.xaml
    /// </summary>
    public partial class CreateNewHeroWindow : Window
    {
        public CreateNewHeroWindow()
        {
            InitializeComponent();
            this.DataContext = new HeroCreatorWindowViewModel();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Hero newHero = new Hero();
            newHero.Name = heros_name.Text;
            newHero.Power = double.Parse(heros_power.Text);
            newHero.Speed = double.Parse(heros_speed.Text);
            newHero.Side = (Side)Enum.Parse(typeof(Side), heros_side.Text);
            
            (this.DataContext as HeroCreatorWindowViewModel).Setup(newHero);
            this.DialogResult = true;
        }
    }
}
