﻿using HeroEditor.Enumerations;
using HeroEditor.Enumerations;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Media;

namespace HeroEditor.Helpers
{
    public class HeroTypeToColor : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var type = (Side)Enum.Parse(typeof(Side), value.ToString());

            switch (type)
            {
                case Side.good:
                    return Brushes.LightGreen;
                    
                case Side.evil:
                    return Brushes.IndianRed;
                    
                case Side.neutral:
                    return Brushes.LightYellow;
                    
                default:
                    return Brushes.White;
                    break;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return Binding.DoNothing;
        }
    }
}
