﻿using HeroEditor.Models;
using System.Collections.Generic;

namespace HeroEditor.Logic
{
    public interface IHeroLogic
    {
        double AVGPower { get; }
        double AVGSpeed { get; }
        void AddToArmy(Hero hero);
        void CreateNewHero();
        void EditHero(Hero hero);
        void RemoveFromArmy(Hero hero);
        void RemoveFromHeros(Hero hero);
        void AddToHeros(Hero hero);
     
        void SetupCollections(IList<Hero> heros, IList<Hero> army);
        void LoadHerosFromHeroJson();
        void LoadHerosFromArmyJson();
        void SaveHerosToHeroJson();
        void SaveHerosToArmyJson();
    }
}