﻿using HeroEditor.Models;
using HeroEditor.Services;
using Microsoft.Toolkit.Mvvm.Messaging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace HeroEditor.Logic
{
    public class HeroLogic : IHeroLogic
    {
        IList<Hero> heros;
        IList<Hero> army;
        IMessenger messenger;
        IHeroEditorService heroEditorService;
        IHeroCreatorService heroCreatorService;


        public HeroLogic(IMessenger messenger,IHeroEditorService heroEditorService,IHeroCreatorService heroCreatorService)
        {
            this.messenger = messenger;
            this.heroEditorService = heroEditorService;
            this.heroCreatorService = heroCreatorService;  
        }        public double AVGPower
        {
            get
            {
                if (army.Count!=0)
                {
                    return Math.Round(army.Average(t => t.Power), 2);
                }
                else
                {
                    return 0;
                }
            }
        }

        public double AVGSpeed
        {
            get
            {
                if (army.Count!=0)
                {
                    return Math.Round(army.Average(t => t.Speed), 2);
                }
                else
                {
                    return 0;
                }
            }
        }
        public void LoadHerosFromArmyJson()
        {
            var fileName = "Army.json";
            var size = new FileInfo(fileName).Length;
            if (File.Exists(fileName) && size != 0)
            {
                var file = File.ReadAllText(fileName);
                var herosFromJson = JsonConvert.DeserializeObject<IList<Hero>>(file);
                foreach (var hero in herosFromJson)
                {
                    army.Add(hero);
                }
            }
        }
        public void LoadHerosFromHeroJson()
        {
            var fileName = "Heros.json";
            var size = new FileInfo(fileName).Length;
            if (File.Exists(fileName) && size != 0)
            {
                var file = File.ReadAllText(fileName);
                var herosFromJson = JsonConvert.DeserializeObject<IList<Hero>>(file);
                foreach (var hero in herosFromJson)
                {
                    heros.Add(hero);
                }
            }
            
        }
        public void SaveHerosToArmyJson()
        {
            var fileName = "Army.json";
            var json = JsonConvert.SerializeObject(army, Formatting.Indented);
            File.WriteAllText(fileName, json);
        }
        public void SaveHerosToHeroJson()
        {
            var fileName = "Heros.json";
            var json = JsonConvert.SerializeObject(heros, Formatting.Indented);
            File.WriteAllText(fileName, json);
        }
        public void SetupCollections(IList<Hero> heros, IList<Hero> army)
        {
            this.heros = heros;
            this.army = army;
        }
        public void AddToArmy(Hero hero)
        {
            army.Add(hero);
            heros.Remove(hero);
            messenger.Send("Hero added", "HeroInfo");
        }
        public void AddToHeros(Hero hero/*, IList<Hero> herosList*/)
        {
            //herosList = heros;
            heros.Add(hero);
            messenger.Send("Hero added to heros", "HeroInfo");
        }
        public void RemoveFromArmy(Hero hero)
        {
            army.Remove(hero);
            heros.Add(hero);
            messenger.Send("Hero removed", "HeroInfo");
        }
        public void RemoveFromHeros(Hero hero)
        {
            var answer = MessageBox.Show("Are you sure that you want to remove the choosen hero?", "Question", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (answer == MessageBoxResult.Yes)
            {
                heros.Remove(hero);
                messenger.Send("Hero removed from heros permanently", "HeroInfo");
            } 
        }

        public void EditHero(Hero hero)
        {
            heroEditorService.Edit(hero);
            messenger.Send("Trooper edited","TrooperInfo");
        }
        public void CreateNewHero()
        {
            heroCreatorService.CreateHero();
            messenger.Send("Trooper created", "TrooperInfo");
        }

        //public void AddNewlyCreatedHeroToHeros()
        //{
        //    //var newHero = new Hero();

        //    //newHero.Name = heros_name.Text;
        //    //newHero.Power = double.Parse(heros_power.Text);
        //    //newHero.Speed = double.Parse(heros_speed.Text);
        //    //newHero.Side = (Side)Enum.Parse(typeof(Side), heros_side.Text);

        //    //viewModel.AddHeroToHeros(newHero);

        //    //this.DialogResult = true;
        //}
    }
}
