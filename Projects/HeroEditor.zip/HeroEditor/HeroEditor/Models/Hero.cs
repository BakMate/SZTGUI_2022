﻿using HeroEditor.Enumerations;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeroEditor.Models
{
    

    public class Hero : ObservableObject
    {
        private double speed;

        public double  Speed
        {
            get { return speed; }
            set { SetProperty(ref speed, value); }
        }

        private double power;

        public double Power
        {
            get { return power; }
            set { SetProperty(ref power, value); }
        }

        private string name;

        public string Name
        {
            get { return name; }
            set { SetProperty(ref name, value); }
        }

        private Side side;

        public Side Side
        {
            get { return side; }
            set { SetProperty(ref side, value); }
        }

        public Hero GetCopy()
        {
            return new Hero()
            {
                Name = this.Name,
                Power = this.Power,
                Speed = this.Speed
            };
        }

    }
}
