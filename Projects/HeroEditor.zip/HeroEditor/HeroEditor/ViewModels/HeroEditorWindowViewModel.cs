﻿using HeroEditor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeroEditor.ViewModels
{
    public class HeroEditorWindowViewModel
    {
        public Hero ActualHero { get; set; }

        public void Setup(Hero hero)
        {
            this.ActualHero = hero;
        }


        public HeroEditorWindowViewModel()
        {

        }
    }
}
