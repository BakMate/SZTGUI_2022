﻿using HeroEditor.Enumerations;
using HeroEditor.Logic;
using HeroEditor.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.DependencyInjection;
using Microsoft.Toolkit.Mvvm.Input;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace HeroEditor.ViewModels
{
    public class MainWindowViewModel : ObservableRecipient
    {
        IHeroLogic logic;


        public void AddHeroToHeros(Hero hero)
        {
            logic.AddToHeros(hero);
        }
        public void SaveHerosToHeroJson()
        {
            logic.SaveHerosToHeroJson();
        }

        public void SaveHerosToArmyJson()
        {
            logic.SaveHerosToArmyJson();
        }

        public void LoadHerosFromHeroJson()
        {
            logic.LoadHerosFromHeroJson();
        }

        public void LoadHerosFromArmyJson()
        {
            logic.LoadHerosFromArmyJson();
        }
        public ICommand AddToArmyCommand { get; set; }
        public ICommand RemoveFromArmyCommand { get; set; }
        public ICommand EditHeroCommand { get; set; }
        public ICommand CreateNewHeroCommand { get; set; }
        public ICommand RemoveFromHerosCommand { get; set; }

        public ObservableCollection<Hero> Heros { get; set; }
        public ObservableCollection<Hero> Army { get; set; }

        private Hero selectedFromHeros;

        public Hero SelectedFromHeros
        {
            get { return selectedFromHeros; }
            set
            {
                SetProperty(ref selectedFromHeros, value);
                (AddToArmyCommand as RelayCommand).NotifyCanExecuteChanged();
                (EditHeroCommand as RelayCommand).NotifyCanExecuteChanged();
                (RemoveFromHerosCommand as RelayCommand).NotifyCanExecuteChanged();


            }
        }

        private Hero selectedFromArmy;

        public Hero SelectedFromArmy
        {
            get { return selectedFromArmy; }
            set
            {
                SetProperty(ref selectedFromArmy, value);
                (RemoveFromArmyCommand as RelayCommand).NotifyCanExecuteChanged();

            }
        }

        private Side selectedHeroSide;

        public Side SelectedHeroSide
        {
            get { return selectedHeroSide; }
            set
            {
                SetProperty(ref selectedHeroSide, value);
            }
        }

        public double AVGPower
        {
            get
            {
                return logic.AVGPower;
            }
        }

        public double AVGSpeed
        {
            get
            {
                return logic.AVGSpeed;
            }
        }


        public static bool IsInDesignMode
        {
            get
            {
                var prop = DesignerProperties.IsInDesignModeProperty;
                return (bool)DependencyPropertyDescriptor.FromProperty(prop, typeof(FrameworkElement)).Metadata.DefaultValue;
            }
        }



        public MainWindowViewModel()
            : this(IsInDesignMode ? null : Ioc.Default.GetService<IHeroLogic>())
        {

        }

        public MainWindowViewModel(IHeroLogic logic)
        {
            this.logic = logic;
            Heros = new ObservableCollection<Hero>();
            Army = new ObservableCollection<Hero>();

            logic.SetupCollections(Heros, Army);

            //Heros.Add(new Hero()
            //{
            //    Name = "Thor",
            //    Power = 8,
            //    Speed = 6,
            //    Side = Side.good
            //});
            //Heros.Add(new Hero()
            //{
            //    Name = "IronMan",
            //    Power = 7,
            //    Speed = 3,
            //    Side = Side.good
            //});
            //Heros.Add(new Hero()
            //{
            //    Name = "Hulk",
            //    Power = 6,
            //    Speed = 8,
            //    Side = Side.good
            //});
            //Heros.Add(new Hero()
            //{
            //    Name = "Loki",
            //    Power = 3,
            //    Speed = 3,
            //    Side = Side.evil
            //});
            //Heros.Add(new Hero()
            //{
            //    Name = "Dr Strange",
            //    Power = 5,
            //    Speed = 6,
            //    Side = Side.neutral
            //});

            //Army.Add(Heros[2].GetCopy());
            //Army.Add(Heros[4].GetCopy());



            AddToArmyCommand = new RelayCommand(
                () => logic.AddToArmy(SelectedFromHeros),
                () => SelectedFromHeros != null
                );

            RemoveFromArmyCommand = new RelayCommand(
                () => logic.RemoveFromArmy(SelectedFromArmy),
                () => SelectedFromArmy != null
                );

            EditHeroCommand = new RelayCommand(
               () => logic.EditHero(SelectedFromHeros),
               () => SelectedFromHeros != null
               );

            CreateNewHeroCommand = new RelayCommand(
                () => logic.CreateNewHero()
                //() => SelectedFromHeros != null
                );

            RemoveFromHerosCommand = new RelayCommand(
                () => logic.RemoveFromHeros(SelectedFromHeros),
                () => SelectedFromHeros != null
                );

            Messenger.Register<MainWindowViewModel, string, string>(this, "HeroInfo", (recipient, msg) =>
            {
                //OnPropertyChanged("AllCost");
                OnPropertyChanged("AVGPower");
                OnPropertyChanged("AVGSpeed");
            });



        }
    }
}
