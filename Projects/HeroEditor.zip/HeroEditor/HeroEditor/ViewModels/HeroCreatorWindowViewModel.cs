﻿using HeroEditor.Logic;
using HeroEditor.Models;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeroEditor.ViewModels
{
    public class HeroCreatorWindowViewModel : ObservableRecipient
    {
        IHeroLogic logic;

        public HeroCreatorWindowViewModel() : this(Ioc.Default.GetService<IHeroLogic>())
        {

        }

        public HeroCreatorWindowViewModel(IHeroLogic heroLogic)
        {
            this.logic = heroLogic;
        }

        public void Setup(Hero hero)
        {
            logic.AddToHeros(hero);
        }
    }
}
