﻿using HeroEditor.Logic;
using HeroEditor.Models;
using HeroEditor.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HeroEditor
{
    /// <summary>
    /// Interaction logic for HeroEditorWindow.xaml
    /// </summary>
    public partial class HeroEditorWindow : Window
    {
       
        public HeroEditorWindow(Hero hero)
        {
            InitializeComponent();
            //var vm = new HeroEditorWindowViewModel();
            //vm.Setup(hero);


            //viewModel = new MainWindowViewModel();

            this.DataContext = new HeroEditorWindowViewModel();
            (this.DataContext as HeroEditorWindowViewModel).Setup(hero);
        }

        private void Vm_EditedDone(object? sender, EventArgs e)
        {
            this.DialogResult = true;
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            foreach (var hero in editorStack.Children)
            {
                if (hero is TextBox t)
                {
                    t.GetBindingExpression(TextBox.TextProperty).UpdateSource();
                }
                if (hero is ComboBox c)
                {
                    c.GetBindingExpression(ComboBox.TextProperty).UpdateSource();
                }
            }
            //viewModel.SaveHerosToJson();
            this.DialogResult = true;
        }
    }
}
