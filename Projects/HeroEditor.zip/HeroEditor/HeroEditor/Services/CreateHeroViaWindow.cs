﻿using HeroEditor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeroEditor.Services
{

    public class CreateHeroViaWindow : IHeroCreatorService
    {
        public void CreateHero()
        {
            new CreateNewHeroWindow().ShowDialog(); 
        }

        public Hero GiveHero()
        {
            CreateNewHeroWindow CreateNewHeroWindow = new CreateNewHeroWindow();
            Hero newHero = new Hero();
            newHero = (Hero)CreateNewHeroWindow.DataContext;
            return newHero;
        }
    }
}
