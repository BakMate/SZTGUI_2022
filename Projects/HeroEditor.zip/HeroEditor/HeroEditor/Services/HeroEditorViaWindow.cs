﻿using HeroEditor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HeroEditor.Services
{
    public class HeroEditorViaWindow : IHeroEditorService
    {
        public void Edit(Hero hero)
        {
            new HeroEditorWindow(hero).ShowDialog();
        }

    }
}
